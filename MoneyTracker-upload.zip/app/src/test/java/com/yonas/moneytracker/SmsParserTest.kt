package com.yonas.moneytracker

import com.yonas.moneytracker.data.TxType
import com.yonas.moneytracker.sms.SmsParser
import org.junit.Assert.*
import org.junit.Test

class SmsParserTest {

    @Test fun cbe_debit() {
        val r = SmsParser.parse("CBE", "Dear Yonas your Account 1*****1234 has been debited with ETB 1,500.00. Your Current Balance is ETB 8,250.50.")!!
        assertEquals(TxType.EXPENSE, r.type)
        assertEquals(1500.0, r.amount, 0.001)
        assertEquals(8250.5, r.balance!!, 0.001)
    }

    @Test fun cbe_credit() {
        val r = SmsParser.parse("CBE", "Dear Yonas your Account 1*****1234 has been credited with ETB 25,000.00. Your Current Balance is ETB 33,250.50.")!!
        assertEquals(TxType.INCOME, r.type)
        assertEquals(25000.0, r.amount, 0.001)
        assertEquals(33250.5, r.balance!!, 0.001)
    }

    @Test fun telebirr_sent() {
        val r = SmsParser.parse("127", "Dear Yonas You have transferred ETB 200.00 to Abebe Kebede (2519****1234) on 28/09/2026. Your current balance is ETB 1,340.75.")!!
        assertEquals(TxType.EXPENSE, r.type)
        assertEquals(200.0, r.amount, 0.001)
        assertEquals(1340.75, r.balance!!, 0.001)
    }

    @Test fun telebirr_received() {
        val r = SmsParser.parse("127", "Dear Yonas You have received ETB 500.00 from Kebede Alemu (2519****5678). Your current balance is ETB 1,840.75.")!!
        assertEquals(TxType.INCOME, r.type)
        assertEquals(500.0, r.amount, 0.001)
    }

    @Test fun airtime_is_categorized() {
        val r = SmsParser.parse("127", "You have bought airtime ETB 50.00. Your current balance is ETB 900.00.")
        assertNotNull(r)
        assertEquals(TxType.EXPENSE, r!!.type)
        assertEquals("Airtime & Data", r.category)
    }

    @Test fun amount_after_currency_word() {
        val r = SmsParser.parse("AWASH", "Your account has been credited with 3,200.00 Birr. Balance: 10,000.00 Birr")!!
        assertEquals(TxType.INCOME, r.type)
        assertEquals(3200.0, r.amount, 0.001)
        assertEquals(10000.0, r.balance!!, 0.001)
    }

    @Test fun otp_is_ignored() {
        assertNull(SmsParser.parse("CBE", "Your OTP is 482913. Do not share it with anyone."))
    }

    @Test fun ad_message_is_ignored() {
        assertNull(SmsParser.parse("PROMO", "Get 20% off at our shop this weekend only!"))
    }

    @Test fun no_money_words_returns_null() {
        assertNull(SmsParser.parse("Friend", "Hi are we meeting at 5 pm today?"))
    }
}
