package com.yonas.moneytracker.sms

import com.yonas.moneytracker.data.TxType

data class ParsedSms(
    val type: TxType,
    val amount: Double,
    val balance: Double?,
    val category: String
)

/**
 * Reads a bank / wallet SMS and pulls out: money in or out, amount, balance.
 * Works for Ethiopian banks (CBE, Awash, Dashen, Abyssinia, Wegagen, Nib, Zemen, Oromia, Hibret...)
 * and Telebirr / M-Pesa. Unknown formats use the generic fallback.
 * Returns null when the SMS is not a money message (OTP, ads, etc).
 */
object SmsParser {

    // Words that mean money left the account
    private val debitWords = listOf(
        "debited", "debit", "withdrawn", "withdrawal", "you have paid", "paid to",
        "you have sent", "sent to", "transferred to", "transfer to", "purchase",
        "payment of", "airtime", "bill payment", "deducted", "cash out", "you have transferred"
    )

    // Words that mean money entered the account
    private val creditWords = listOf(
        "credited", "credit", "deposited", "deposit", "you have received",
        "received from", "received", "cash in", "salary", "refund"
    )

    // Messages we must never treat as transactions
    private val ignoreWords = listOf(
        "otp", "one time password", "one-time password", "verification code",
        "do not share", "pin", "promo", "offer", "congratulations you won"
    )

    private const val NUM = """(\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)"""
    private const val CUR = """(?:ETB|Birr|Br\.?|birr)"""

    // "ETB 1,500.00"  or  "1,500.00 ETB"  or  "Birr 1500"
    private val amountRegexes = listOf(
        Regex("""$CUR\s*$NUM""", RegexOption.IGNORE_CASE),
        Regex("""$NUM\s*$CUR""", RegexOption.IGNORE_CASE)
    )

    private val balanceRegexes = listOf(
        Regex("""(?:current\s+)?(?:available\s+)?balance(?:\s+is|\s+now|\s+of)?\s*[:\-]?\s*$CUR?\s*$NUM""", RegexOption.IGNORE_CASE),
        Regex("""bal(?:\.|ance)?\s*[:\-]?\s*$CUR?\s*$NUM""", RegexOption.IGNORE_CASE),
        Regex("""balance[^0-9]{0,20}$NUM""", RegexOption.IGNORE_CASE)
    )

    fun parse(sender: String, body: String): ParsedSms? {
        val text = body.replace("\n", " ").replace(Regex("\\s+"), " ").trim()
        val lower = text.lowercase()

        if (ignoreWords.any { lower.contains(it) } && !looksLikeMoneyMessage(lower)) return null

        val type = detectType(lower) ?: return null
        val balance = findBalance(text)
        val amount = findAmount(text, balance) ?: return null
        if (amount <= 0.0) return null

        return ParsedSms(type, amount, balance, Categorizer.guess(lower, type))
    }

    private fun looksLikeMoneyMessage(lower: String) =
        (debitWords + creditWords).any { lower.contains(it) } && lower.contains("balance")

    /** Decide income vs expense. The word that appears FIRST wins, so
     *  "credited ... your debit card" does not get confused. */
    private fun detectType(lower: String): TxType? {
        val d = debitWords.mapNotNull { w -> lower.indexOf(w).takeIf { it >= 0 }?.let { it to w } }.minByOrNull { it.first }
        val c = creditWords.mapNotNull { w -> lower.indexOf(w).takeIf { it >= 0 }?.let { it to w } }.minByOrNull { it.first }
        return when {
            d == null && c == null -> null
            d == null -> TxType.INCOME
            c == null -> TxType.EXPENSE
            // "received" appears inside "you have received" etc - earliest word decides
            d.first < c.first -> TxType.EXPENSE
            else -> TxType.INCOME
        }
    }

    private fun findBalance(text: String): Double? {
        for (r in balanceRegexes) {
            val m = r.find(text) ?: continue
            return m.groupValues.last { it.isNotEmpty() }.toAmount()
        }
        return null
    }

    /** First money amount in the message that is NOT the balance and NOT a fee/charge line. */
    private fun findAmount(text: String, balance: Double?): Double? {
        val candidates = mutableListOf<Pair<Int, Double>>()
        for (r in amountRegexes) {
            for (m in r.findAll(text)) {
                val v = m.groupValues[1].toAmount() ?: continue
                candidates += m.range.first to v
            }
        }
        val sorted = candidates.sortedBy { it.first }.map { it.second }
        // skip the value that is the balance, take the first other one
        return sorted.firstOrNull { balance == null || it != balance } ?: sorted.firstOrNull()
    }

    private fun String.toAmount(): Double? = replace(",", "").toDoubleOrNull()
}

/** Puts each transaction in a simple category by keywords. User can change it later. */
object Categorizer {
    private val rules = listOf(
        "Airtime & Data" to listOf("airtime", "recharge", "data package", "ethio telecom", "safaricom", "mobile package"),
        "Bills & Utilities" to listOf("electric", "water", "ethiopian electric", "eeu", "bill payment", "dstv", "utility"),
        "Transport" to listOf("ride", "taxi", "fuel", "petrol", "transport", "ethiopian airlines", "bus"),
        "Food & Shopping" to listOf("supermarket", "restaurant", "cafe", "shop", "market", "pos", "merchant", "purchase"),
        "Cash Withdrawal" to listOf("atm", "withdraw", "cash out"),
        "Salary" to listOf("salary", "payroll"),
        "Transfer" to listOf("transfer", "sent to", "received from", "you have sent", "you have received")
    )

    fun guess(lower: String, type: TxType): String {
        for ((cat, words) in rules) if (words.any { lower.contains(it) }) return cat
        return if (type == TxType.INCOME) "Other Income" else "Other Expense"
    }
}
