package com.yonas.moneytracker.sms

import android.content.Context
import com.yonas.moneytracker.data.AppDatabase
import com.yonas.moneytracker.data.Transaction

/** Shared by the live receiver and the old-SMS importer. */
object SmsProcessor {

    /** Returns true if a new transaction was saved. */
    suspend fun process(context: Context, sender: String, body: String, timestamp: Long): Boolean {
        val parsed = SmsParser.parse(sender, body) ?: return false
        val key = "$sender|$timestamp|${body.hashCode()}"
        val id = AppDatabase.get(context).dao().insert(
            Transaction(
                sender = sender,
                type = parsed.type,
                amount = parsed.amount,
                balance = parsed.balance,
                category = parsed.category,
                timestamp = timestamp,
                rawText = body,
                smsKey = key
            )
        )
        return id != -1L
    }
}
