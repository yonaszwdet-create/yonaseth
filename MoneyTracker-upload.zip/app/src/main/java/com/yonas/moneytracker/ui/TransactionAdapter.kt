package com.yonas.moneytracker.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.yonas.moneytracker.R
import com.yonas.moneytracker.data.Transaction
import com.yonas.moneytracker.data.TxType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TransactionAdapter(
    private val onClick: (Transaction) -> Unit
) : ListAdapter<Transaction, TransactionAdapter.VH>(Diff) {

    object Diff : DiffUtil.ItemCallback<Transaction>() {
        override fun areItemsTheSame(a: Transaction, b: Transaction) = a.id == b.id
        override fun areContentsTheSame(a: Transaction, b: Transaction) = a == b
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val category: TextView = v.findViewById(R.id.txCategory)
        val sub: TextView = v.findViewById(R.id.txSub)
        val amount: TextView = v.findViewById(R.id.txAmount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_transaction, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val t = getItem(position)
        val fmt = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
        h.category.text = t.category
        h.sub.text = "${t.sender} · ${fmt.format(Date(t.timestamp))}"
        val income = t.type == TxType.INCOME
        h.amount.text = (if (income) "+" else "-") + Money.format(t.amount)
        h.amount.setTextColor(Color.parseColor(if (income) "#1B7F3B" else "#C62828"))
        h.itemView.setOnClickListener { onClick(t) }
    }
}

object Money {
    fun format(v: Double): String = String.format(Locale.US, "%,.2f", v)
}
