package com.yonas.moneytracker.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.yonas.moneytracker.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val vm: MainViewModel by viewModels()

    private val categories = listOf(
        "Airtime & Data", "Bills & Utilities", "Transport", "Food & Shopping",
        "Cash Withdrawal", "Salary", "Transfer", "Other Income", "Other Expense"
    )

    private val askPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) {
            vm.importOldSms()
        } else {
            Toast.makeText(this, "SMS permission is needed to track your money", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        val adapter = TransactionAdapter { tx ->
            AlertDialog.Builder(this)
                .setTitle("Change category")
                .setItems(categories.toTypedArray()) { _, i -> vm.changeCategory(tx.id, categories[i]) }
                .show()
        }
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter

        vm.transactions.observe(this) {
            adapter.submitList(it)
            b.empty.visibility = if (it.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        }
        vm.income.observe(this) { b.income.text = Money.format(it ?: 0.0) }
        vm.expense.observe(this) { b.expense.text = Money.format(it ?: 0.0) }
        vm.balance.observe(this) { b.balance.text = if (it == null) "—" else "ETB " + Money.format(it) }
        vm.byCategory.observe(this) { rows ->
            b.categories.text = if (rows.isEmpty()) "No spending yet"
            else rows.joinToString("\n") { "${it.category}:  ETB ${Money.format(it.total)}" }
        }
        vm.importResult.observe(this) {
            Toast.makeText(this, "Found $it transactions from your messages", Toast.LENGTH_LONG).show()
        }

        b.tabs.setOnCheckedStateChangeListener { _, ids ->
            when (ids.firstOrNull()) {
                b.chipToday.id -> vm.setPeriod(Period.TODAY)
                b.chipWeek.id -> vm.setPeriod(Period.WEEK)
                b.chipMonth.id -> vm.setPeriod(Period.MONTH)
                b.chipAll.id -> vm.setPeriod(Period.ALL)
            }
        }
        b.chipMonth.isChecked = true

        b.scan.setOnClickListener { ensurePermissionThenScan() }
        ensurePermissionThenScan()
    }

    private fun ensurePermissionThenScan() {
        val need = arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS)
        val granted = need.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
        if (granted) vm.importOldSms() else askPermission.launch(need)
    }
}
