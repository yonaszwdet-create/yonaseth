package com.yonas.moneytracker.sms

import android.content.Context
import android.net.Uri

/** Reads old SMS already in the phone inbox (needs READ_SMS permission). */
object SmsImporter {

    /** Returns how many new transactions were added. */
    suspend fun importInbox(context: Context, sinceMillis: Long = 0L): Int {
        var added = 0
        val cursor = context.contentResolver.query(
            Uri.parse("content://sms/inbox"),
            arrayOf("address", "body", "date"),
            "date >= ?",
            arrayOf(sinceMillis.toString()),
            "date ASC"
        ) ?: return 0

        cursor.use {
            val iAddr = it.getColumnIndexOrThrow("address")
            val iBody = it.getColumnIndexOrThrow("body")
            val iDate = it.getColumnIndexOrThrow("date")
            while (it.moveToNext()) {
                val ok = SmsProcessor.process(
                    context,
                    it.getString(iAddr) ?: "",
                    it.getString(iBody) ?: "",
                    it.getLong(iDate)
                )
                if (ok) added++
            }
        }
        return added
    }
}
