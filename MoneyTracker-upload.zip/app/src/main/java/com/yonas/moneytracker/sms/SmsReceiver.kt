package com.yonas.moneytracker.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Runs every time a new SMS arrives, even when the app is closed. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        // Long SMS arrive in parts - join parts from the same sender
        val grouped = messages.groupBy { it.originatingAddress ?: "" }
        val pending = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                for ((sender, parts) in grouped) {
                    val body = parts.joinToString("") { it.messageBody ?: "" }
                    val time = parts.first().timestampMillis
                    SmsProcessor.process(context, sender, body, time)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
