package com.yonas.moneytracker.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.map
import androidx.lifecycle.switchMap
import androidx.lifecycle.viewModelScope
import com.yonas.moneytracker.data.AppDatabase
import com.yonas.moneytracker.data.CategoryTotal
import com.yonas.moneytracker.data.Transaction
import com.yonas.moneytracker.data.TxType
import com.yonas.moneytracker.sms.SmsImporter
import kotlinx.coroutines.launch
import java.util.Calendar

enum class Period { TODAY, WEEK, MONTH, ALL }

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()

    private val period = MutableLiveData(Period.MONTH)
    private val from: LiveData<Long> = period.map { startOf(it) }

    val transactions: LiveData<List<Transaction>> = from.switchMap { dao.since(it) }
    val income: LiveData<Double> = from.switchMap { dao.total(TxType.INCOME, it) }
    val expense: LiveData<Double> = from.switchMap { dao.total(TxType.EXPENSE, it) }
    val byCategory: LiveData<List<CategoryTotal>> = from.switchMap { dao.expenseByCategory(it) }
    val balance: LiveData<Double?> = dao.latestBalance()

    val importResult = MutableLiveData<Int>()

    fun setPeriod(p: Period) { period.value = p }
    fun currentPeriod(): Period = period.value ?: Period.MONTH

    fun importOldSms() = viewModelScope.launch {
        importResult.postValue(SmsImporter.importInbox(getApplication()))
    }

    fun changeCategory(id: Long, category: String) = viewModelScope.launch {
        dao.setCategory(id, category)
    }

    private fun startOf(p: Period): Long {
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        when (p) {
            Period.TODAY -> {}
            Period.WEEK -> c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
            Period.MONTH -> c.set(Calendar.DAY_OF_MONTH, 1)
            Period.ALL -> return 0L
        }
        return c.timeInMillis
    }
}
