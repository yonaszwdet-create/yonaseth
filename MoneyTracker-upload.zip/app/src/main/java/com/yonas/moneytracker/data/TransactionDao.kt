package com.yonas.moneytracker.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface TransactionDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(tx: Transaction): Long

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun all(): LiveData<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE timestamp >= :from ORDER BY timestamp DESC")
    fun since(from: Long): LiveData<List<Transaction>>

    @Query("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type = :type AND timestamp >= :from")
    fun total(type: TxType, from: Long): LiveData<Double>

    @Query("SELECT category, SUM(amount) AS total FROM transactions WHERE type = 'EXPENSE' AND timestamp >= :from GROUP BY category ORDER BY total DESC")
    fun expenseByCategory(from: Long): LiveData<List<CategoryTotal>>

    @Query("UPDATE transactions SET category = :category WHERE id = :id")
    suspend fun setCategory(id: Long, category: String)

    @Query("SELECT balance FROM transactions WHERE balance IS NOT NULL ORDER BY timestamp DESC LIMIT 1")
    fun latestBalance(): LiveData<Double?>
}

data class CategoryTotal(val category: String, val total: Double)
