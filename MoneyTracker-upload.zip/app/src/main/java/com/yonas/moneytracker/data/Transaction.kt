package com.yonas.moneytracker.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class TxType { INCOME, EXPENSE }

@Entity(
    tableName = "transactions",
    indices = [Index(value = ["smsKey"], unique = true)]
)
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String,
    val type: TxType,
    val amount: Double,
    val balance: Double?,
    val category: String,
    val timestamp: Long,
    val rawText: String,
    // sender + timestamp + text hash, prevents saving the same SMS twice
    val smsKey: String
)
