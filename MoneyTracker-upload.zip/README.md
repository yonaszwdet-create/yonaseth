# Money Tracker (Android)

Reads your bank and Telebirr SMS automatically and tracks money in, money out, and balance.
Everything stays on your phone. Nothing is uploaded.

## How to build the APK
1. Install Android Studio (free): https://developer.android.com/studio
2. Open Android Studio -> File -> Open -> choose this MoneyTracker folder
3. Wait for Gradle sync to finish (first time downloads files, needs internet)
4. Connect your Android phone with USB debugging ON (Settings -> Developer options)
5. Press the green Run button

To get an APK file to share: Build -> Build Bundle(s)/APK(s) -> Build APK(s)

## First use
- Open the app, allow the SMS permission
- It scans your old messages, then catches every new SMS by itself
- Tap any transaction to change its category

## Works with
CBE, Telebirr, Awash, Dashen, Abyssinia, Wegagen, Nib, Zemen, Oromia, Hibret and any bank
that writes "debited / credited / received / transferred" with an ETB or Birr amount.

## Important
- Android only. iPhone does not allow apps to read SMS.
- Google Play blocks SMS apps unless approved, so install the APK directly on your phone.
- If one of your banks is not read correctly, send me that SMS text (hide your name and
  account number) and I will fix the parser.
